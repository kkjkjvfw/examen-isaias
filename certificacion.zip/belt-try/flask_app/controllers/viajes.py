# controladores/viajes.py
from flask import render_template, redirect, request, flash, session, url_for
from flask_app.models.viaje import Viaje
from datetime import datetime
from flask_app import app




@app.route('/nuevo_viaje', methods=['GET', 'POST'])
def nuevo_viaje():
    if request.method == 'GET':
        return render_template('nuevo.html')
    
    if request.method == 'POST':
        # Crear diccionario con los datos del formulario
        data = {
            'destino': request.form['destino'],
            'fecha_inicio': request.form['fechaInicio'],
            'fecha_fin': request.form['fechaFin'],
            'itinerario': request.form['itinerario'],
            'id_organizador': session['usuario_id']  # Desde la sesión
        }

        # Validar los datos
        errores = Viaje.validar_viaje(data)
        if errores:
            for error in errores:
                flash(error, 'error')
            return render_template('nuevo.html', data=data)

        # Crear el viaje
        viaje_id = Viaje.crear(data)
        if viaje_id:
            flash('Viaje creado exitosamente', 'success')
            return redirect(url_for('dashboard'))
        
        flash('Error al crear el viaje', 'error')
        return render_template('nuevo.html', data=data)

@app.route('/ver_viaje/<int:id>')
def ver_viaje(id):
    viaje = Viaje.obtener_por_id(id)
    if not viaje:
        flash('Viaje no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('ver_viaje.html', viaje=viaje)

@app.route('/eliminar_viaje/<int:id>')
def eliminar_viaje(id):
    if Viaje.eliminar(id):
        flash('Viaje eliminado exitosamente', 'success')
    else:
        flash('Error al eliminar el viaje', 'error')
    return redirect(url_for('dashboard'))


@app.route("/editar_viaje/<int:id>")
def editar_viaje(id):
    if 'usuario_id' not in session:
        return redirect('/login')
    
    viaje = Viaje.obtener_por_id(id)
    if viaje.id_organizador != session['usuario_id']:
        flash("No tienes permiso para editar este viaje", "error") 
        return redirect(url_for('dashboard'))
    else:
        return render_template("editar_viaje.html", viaje=viaje)
    
@app.route("/actualizar_viaje", methods=['POST'])
def actualizar_viaje():
    if 'usuario_id' not in session:
        return redirect('/login')
    datos = {
        "id_viaje": request.form['id'],
        "destino": request.form['destino'],
        "fecha_inicio": request.form['fechaInicio'],
        "fecha_fin": request.form['fechaFin'],
        "itinerario": request.form['itinerario']
    }
    
    Viaje.actualizar(datos)
    flash("Viaje actualizado exitosamente", "success")
    return redirect(url_for('dashboard'))

    """
    
@app.route('/editar_viaje/<int:id>', methods=['GET', 'POST'])
def editar_viaje(id):
    viaje = Viaje.obtener_por_id(id)
    if not viaje:
        flash('Viaje no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        data = {
            'id_viaje': id,
            'destino': request.form['destino'],
            'fecha_inicio': request.form['fechaInicio'],
            'fecha_fin': request.form['fechaFin'],
            'itinerario': request.form['itinerario'],
        }
        errores = Viaje.validar_viaje(data)
        if errores:
            for error in errores:
                flash(error, 'error')
            return render_template('editar_viaje.html', viaje=data)

        if Viaje.actualizar(data):
            flash('Viaje actualizado exitosamente', 'success')
            print(f"Viaje con ID {id} actualizado correctamente")  # Mensaje en consola
            return redirect(url_for('dashboard'))  # Redirigir a la ruta principal
        
        flash('Error al actualizar el viaje', 'error')
        return render_template('editar_viaje.html', viaje=data)

    return render_template('editar_viaje.html', viaje=viaje)

    """