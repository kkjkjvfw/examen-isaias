# modelos/viaje.py
from flask_app.config.mysqlconnection import connectToMySQL
DATABASE = 'viajes'
class Viaje:
    def __init__(self, data):
        self.id_viaje = data['id_viaje']
        self.destino = data['destino']
        self.fecha_inicio = data['fecha_inicio']
        self.fecha_fin = data['fecha_fin']
        self.itinerario = data['itinerario']
        self.id_organizador = data['id_organizador']
        self.fecha_creacion = data['fecha_creacion']
        self.fecha_actualizacion = data['fecha_actualizacion']
        self.organizador = data.get('organizador', None)  # Para joins con la tabla usuarios

    @classmethod
    def obtener_todos(cls):
        query = """
            SELECT v.*, u.nombre as organizador 
            FROM viajes v
            JOIN usuarios u ON v.id_organizador = u.id_usuario
            ORDER BY v.fecha_inicio;
        """
        results = connectToMySQL(DATABASE).query_db(query)
        viajes = []
        if results:
            for row in results:
                viajes.append(cls(row))
        return viajes

    @classmethod
    def obtener_por_id(cls, id_viaje):
        query = """
            SELECT v.*, u.nombre as organizador 
            FROM viajes v
            JOIN usuarios u ON v.id_organizador = u.id_usuario
            WHERE v.id_viaje = %(id_viaje)s;
        """
        data = {'id_viaje': id_viaje}
        results = connectToMySQL(DATABASE).query_db(query, data)
        return cls(results[0]) if results else None

    @classmethod
    def crear(cls, data):
        query = """
            INSERT INTO viajes (destino, fecha_inicio, fecha_fin, itinerario, id_organizador)
            VALUES (%(destino)s, %(fecha_inicio)s, %(fecha_fin)s, %(itinerario)s, %(id_organizador)s);
        """
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def actualizar(cls, data):
        query = """
            UPDATE viajes 
            SET destino = %(destino)s,
                fecha_inicio = %(fecha_inicio)s,
                fecha_fin = %(fecha_fin)s,
                itinerario = %(itinerario)s
            WHERE id_viaje = %(id_viaje)s;
        """
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def eliminar(cls, id_viaje):
        query = "DELETE FROM viajes WHERE id_viaje = %(id_viaje)s;"
        data = {'id_viaje': id_viaje}
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def obtener_por_organizador(cls, id_organizador):
        query = """
            SELECT v.*, u.nombre as organizador 
            FROM viajes v
            JOIN usuarios u ON v.id_organizador = u.id_usuario
            WHERE v.id_organizador = %(id_organizador)s
            ORDER BY v.fecha_inicio;
        """
        data = {'id_organizador': id_organizador}
        results = connectToMySQL(DATABASE).query_db(query, data)
        viajes = []
        if results:
            for row in results:
                viajes.append(cls(row))
        return viajes

    # Método para validar los datos del viaje
    @staticmethod
    def validar_viaje(data):
        errores = []
        
        # Validar que los campos no estén vacíos
        if not data['destino']:
            errores.append("El destino es obligatorio")
        
        if not data['fecha_inicio']:
            errores.append("La fecha de inicio es obligatoria")
            
        if not data['fecha_fin']:
            errores.append("La fecha de fin es obligatoria")
            
        if not data['itinerario']:
            errores.append("El itinerario es obligatorio")

        # Validar fechas
        if data['fecha_inicio'] and data['fecha_fin']:
            if data['fecha_inicio'] > data['fecha_fin']:
                errores.append("La fecha de inicio no puede ser posterior a la fecha de fin")

        return errores